-=======================================-
     Digital Destruction Suite v1
                Beta2
         (c)1997 Global kOS
-=======================================-

This is the Second beta release of the gkos
Digital Destruction suite, it has somewhat
limited function as of right now.  This
is beta stuff and I plan to be releasing
a new version every week to two weeks
this is beta shit, I just want people to
know I am still out there programming...
I have been pretty busy, and I actually 
have most of the coding done in this ver.
*but* some of it is still in "testbed" 
phase and requires a little bit of 
fiddling around to not generate errors...
SO I decided to turn those off and at 
least let you guys play with a little bit
of what I have done..
now if you were not listening in, Carolyn
Meinel (the lady who runs the "Happy 
Hacker" mailing list) decided to do a 
press release on what I am working on...
seems she has some dude who has ties to
the NSA who is interested in my work..
this is part of the reason for disabling
certain portions...  If I am going to get
into trouble for something like a Denial
of Service (DOS) program, I would prefer
that at least the damn thing was coded
well...

info on the Usenet spammer:
UseNet is nothing but lamers wanting to 
be zeroCool off of "hackers the movie".. and
is probably the worse example of what can
happen to a once fine forum...
if people actually would think about what they
were spewing about it might be tolerable...
all the *real* hackers left that crap way..
way.. behind...
but then *hacker* is a word about as specific
as artist..   the definition has faded beyond
recognition and lost all depth and just about
become meaningless...  I have a shirt that says
"Fuck art lets kill"...  and that is about how
I feel about this crap in usenet...  anyway 

The whole thing with infowar.com was almost a
brilliant masterpiece of Poetic terrorism..  I
think Jon Newton (OTRICS) is going to be
writing up some fine articles about the whole
fiasco...
you can find them at
http://www.the-wire.com/newjon/acid.html


-AcidAngel-  
 
-=======================================-
here is a little FAQ about us..
spidey wrote this up..
-=======================================-
              GkOS FAQ
-=======================================-
	There have been several rumors circulating about what happened to us since
globalkos.org went down.  They range from us being busted by feds to
stories about purple shrouds and phenobarbital.  There have also been
rumors about dissention among our ranks and group infighting.

Q:  What happened to globalkos.org?  Did the feds shut it down?  Did their
ISP shut it   
down?  Did they move their site to keep it hidden?
A:  Half of us didn't feel like paying for it.  We weren't shut down,  nor
is the site hidden out there somewhere.  We're looking into alternatives.

Q:  Did Acid Angel leave GkOS for Technophoria?
A:  No.  He is working with the guys at Technophoria,  but he is still a
part of Global kOS.

Q:  Did Silicon Toad leave the group altogether?
A:  Somebody came up with this one on the basis of a broken link at
globalkos.org.  ST 
moved his site, and no one bothered to update the link.  Through some
stretch of logic 
this guy decided it meant ST split.

Q:  What about Up Yours 4?
A:  It's slated for release on March 30th.

Q:  Did GkOS get busted?
A:  No.

Q:  I thought Cobra (Vortex,  Morbid Disorder, Kludge,  or Ryan) was a
member of 
GkOS.
A:  I've never even heard of these people.  They are not present,  nor
former members.

     Our members are:

Acid Angel
Glitch
Materva
Raven
Shadow Hunter
Silicon Toad
Spidey
That Guy
Zaven

Q:  I heard there was a major disagreement within the group,  and there's a
civil war   
going on between them.  Is it true?
A:  No.  This is completely unfounded.  Whoever started this one pulled it
straight out of his ass.







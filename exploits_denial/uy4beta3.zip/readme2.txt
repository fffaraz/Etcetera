Whatever kind of publicity I get for the program.. well
I like..  the following was send to me by Reverend MindFuck...  he found
it while digging through the crap in Usenet..

an example or sort...  I just like the press for the program I guess


===========================================================================
begin snippet from UseNet:

The following propaganda is Copyright 1997 Ingrid Rimland, posted in the
interest of public oversight. Note that Ingrid Rimland elects not to post
and defend her propaganda publicly; rather, a fully automated script takes
it from her closed mailing list and makes it available for refutation and
ridicule in the best tradition of free speech. Header text last modified
February 20, 1997.

In my opinion, the best resource available on the net for researching and
countering this material is the Nizkor Project, a grass-roots net-based
archive, http://www.nizkor.org/objectives.html. For keyword and concept
searches of material on Nizkor, see http://search.nizkor.org/search.html.
Nizkor now has a mirror site in Germany, http://www1.de.nizkor.org/nizkor/
In the event of temporary network outages, try www1.ca.nizkor.org instead.

While I strongly encourage you to investigate for yourself how and why Ms.
Rimland's writings are maliciously false, if you have any pressing questions
concerning specific assertions below, the address questions@nizkor.org is
available. Alternatively, post your query in alt.revisionism, and someone
will answer. We've seen it all before; there are only so many ways one can
distort historical fact. See the catalogue: http://www.nizkor.org/features/qar/

------------ BEGIN ZUNDELGRAM MESSAGE ------------

March 4, 1997

Good Morning from the Zundelsite:

Here is a telling follow-up on electronic terrorism involving none other
than Nizkor.  Be sure to read it carefully - and act on it if you are so
inclined.

You will remember the massive e-mail attack aimed at our California-based
server, Web Communications, in mid-December.  For 40 hours straight, an
automatic mailer fired three words - "Denial of Service" - at the rate of
200 e-mail messages per second at Webcom - an attack which amounted to a
staggering 28.8 million letters.

This electronic bombardment  shut down the Webcom system and crippled 3,000
websites during the busiest weekend of the Christmas season.  The damage to
customers of Webcom must have been in the hundreds of thousands if not
millions of dollars.

This was the second time that Webcom has been so attacked.  The first
attack came out of Germany via Deutsche Telekom a year ago in response to
an announced and then hotly denied "debate" with the notorious Holocaust
Promotion website, Nizkor - a website opposing Revisionist websites on
grounds that Nizkor's function is to serve the memory of those who died in
the "Holocaust" whom we are wantonly defaming.

Now keep in mind as you read the information below that Nizkor issues tax
deductible receipt via a certain charitable outfit to people who support
their work.  The outfit that collects donations for Nizkor in Canada is
called The Zikaron Tolerance and Remembrance Society.  In the United
States, donations in support of Nizkor are being made payable to San
Antonio Area Foundation  - Nizkor Fund.  Both Canadian and American donors
may deduct their contributions from their income taxes.

You will also recall that while trying to contact Nizkor's head honcho, Ken
McVay, for a broadcast interview, Ernst was directed to a mail drop to
several phone message machines.  Personal e-mail sent to Ken McVay was
answered by none other than B'nai Brith's chief spokesperson on Vancouver
Island, Harry Abrams.  His telephone was answered by a Rabbi Goldberg.
Furthermore, McVay is publicly lionized and promoted on the lecture circuit
by B'nai Brith et al - the folks who like to visit law enforcement quarters
to regale them "sensitivity training" on how to spot and counteract
"racists and terrorists."

We understand that Ken McVay and entourage are giving it their all by
serving to protect the Holocaust Lobbyists from having to answer some
justified questions, such as:  "Did Six Million Really Die?"  For that,
they get official kudos from sundry dignitaries and lots of free publicity
from a beholden media.  Their website URL is frequently listed in articles.
Ken McVay even got the Order of British Columbia from the Queen of England
for his work.
What seems to have been overlooked until now is the incriminating fact that
the allegedly oh so noble folks at Nizkor, who like to seize the moral high
ground in every argument, store detailed information and instructions on
how to engage in electronic computer terrorism on their websites.   This is
tantamount to displaying bomb making instructions on militia sites, which
Nizkor's friends routinely rail about.

This information on the Nizkor website directs people where to find and
download programs needed to execute devastating e-mail bombings.  This is
distinctly not an accidental listing because Nizkor submitted it to be
placed on its own website search engine so that potential electronic
terrorists would easily be able to find it.

There comes a point when the public must be allowed to ask:  "Where does
B'nai Brith's influence and control over Nizkor begin or end?  Does it
include an agenda of electronic terrorism against Holocaust Revisionist
websites or electronic Holocaust Revisionism?

Here is why I ask, in my capacity as the US-based webmaster and editor of
the material posted on the Zundelsite, including "Did Six Million Really
Die?"  Immediately after the massive electronic act of terrorism in
December, I filed a formal complaint with the Royal Canadian Mounted Police
in Nanaimo, B.C., asking that this matter be investigated as a criminal
offense.  I sent this letter, which had been carefully prepared with the
help of an attorney, to a specific police officer, addressing him by name.
I even sent this letter registered.  I asked for an acknowledgment and
action.

Now it is  almost three months later.  So far, I have not yet received an
answer.  RCMP has since been contacted again - still no response.

I will now share the information since obtained with the RCMP as well, as
well as with my readership.  The information is as follows:

At  http://search.nizkor.org/ftp.cgi?miscellany/up-yours-faq, there are
explicit instructions on how to mail bomb an opponent.  Below, I quote some
excerpts from a program called "Up Yours".

It tells you where to get it and urges you to download it, as per the
following, replete with misspellings:

Q:  What is Up Yours?

A:  Up Yours is a program developed by AcidAngel of Global kOS to mail bomb
specific users on the Internet. The present version is 100% completely
anonymous and uses random headers and subject lines and even uses random
servers.  it implements a HELO spoofing technique that is next to
impossible to trace.

Q:  What is a Mailbomb?

A:  A mailbomb does not blow up anyones address, Just think if you got
10,000 e-mail messages and had to download them..  Usually this would take
down the server and have the sysop reprimand the user for angering people
on the Internet.  Some servers have been downed for weeks that I know of
because of certain users.... (that means no e-mail for anyone on that
server)

Q:  What is the advantage of using Up Yours?

A:  You are anonymous, 100%, and it cannot be traced back to you.

Q:  Okay, I'm new to the business, but whats a mailbomner(?) good for???

A:  If you have a user that you really want to get revenge against and have
his ISP (Internet Service Provider) get very mad at him/her  or you simply
want to cripple the user from recieving e-mail for an extended period of
time.

Q:  What does up yours now do? how do you run it? Will it jam up someone
elses computer? is it any good?

A:  It won't jam up anyone elses computer, it will however trash their mail
server and cripple them getting any mail for a long time...  It is the best
war-mailer for Windows 95...

Q:  Do I need it? If yes, then why?

A:  Of course, if everyone else has a gun why would you want a butterknife?

Q:  how much damage will it do?

A:  much, very much."

o here you have a "charitable" organization that takes donations and hands
out tax deductible receipts, pretending to champion a worthy cause and high
ideals of truth and justice - and yet has not just the audacity but the
terrorist mentality to advertise and to promote not only how to hurt a
dissident with whom they disagree but how to hurt a server  and thousands
of this server's totally neutral, apolitical customers.

That's terrorism.  There are six Nizkor mirror sites.  Their websites are
promoted in schools as a "legitimate" Holocaust resource by public agencies
and officials.

Are these public officials mere dupes, inflicting on their lower ranks
their brand of political correctness while being fooled by Nizkor's
electronic warfare experts - or worse?

Is someone trying to entice and introduce school children to computer
terrorism - or worse?

The FBI was, and presumably still is, investigating the massive disruption
of Webcom's business.  It has already been established that the computers
at a college in Nanaimo, B.C., the city listed as a PO Box mail drop by
Nizkor.  played a key function in this crime of electronic terrorism.  It
would be very strange indeed if this were a coincidence.

I think both parents and the public, as well as public officials, have a
right to a straight answer - not only from Nizkor about what that
electronic terrorism information, replete with instructions, is doing on
their website but also from educators and government officials who use,
promote and champion that website.  Do they condone or even deliberately
encourage the learning of computer crime via Nizkor's websites and its
mirror sites to silence political opponents?

I would strongly encourage my readers to contact Staff Sgt. Ken Smith at
303 Prideaux Street, Nanaimo, B.C. Canada V9R 2N3.   His phone number is
250-754-2345 and his fax is 250-753-0946.  It seems that in the new Canada
even the police needs to be counter-lobbied, since they seem to have been
either cowed or mentally captured by too much "sensitivity training" while
closing eyes and ears to real, 20th century electronic  terrorism
masquerading as protection of the "Holocaust".

I want to say in closing that the president of Webcom, Chris Schefler, who
is Jewish, has behaved towards us in an absolutely impeccable professional
manner.  We have never received anything but the finest of service from
him.  Webcom has stuck to their "freedom of speech" stance even during this
second, more vicious, crippling and financially damaging attack, and  even
though the owner of this server disagrees with us and has been greatly
inconvenienced.  The irresponsibility that Nizkor has displayed with its
listing of instructions on how to mail-bomb an opponent does not help
decent Jews with standards.  Or, for that matter, inter-ethnic harmony.
Nor does it aid the "memory of the victims of the Holocaust" one bit.

Ingrid



Thought for the Day:

"I feel building up in this country enormous resentment, mostly political,
waiting to be captured."

(David Riesman)






________
________
________ The Zundelsite can be found at
http://www.webcom.com/ezundel/english/


------------ END ZUNDELGRAM MESSAGE ------------
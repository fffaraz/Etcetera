pantherm.exe is a very simple Denial of service UDP based attack
that is designed for a 28.8-56k connection.
panther2.exe is the same but designed with a pentium 200 on 128k-T3

these are pretty effective weapons I decided to throw along in the
release of Beta 3.  They will *not* flood anyone off of IRC, (SYN only 
affects servers) they will however make a server unable to accept any
incoming requests as long as conditions are met.

these are still in developmental phase, and testing is kind of 
difficult as it is illegal to fully test this..  But my beta testers
seemed to have promising results against firewalls and temporary servers
set up for testing this program.


again I cannot be held liable for this program.. please see disclaimer.

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#include <dirent.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <ctype.h>
#include "config.h"

/* Insert desperate attempts at portability here */
#ifdef __linux__
#ifndef __GLIBC__
#define icmp_type	type
#define	ip		iphdr
#define	icmp		icmphdr
#define	ip_len		tot_len
#else /* glibc */
#define saddr	ip_src.s_addr
#endif /* glibc */
#else /* linux */
#define saddr	ip_src.s_addr
#endif /* linux */

float kbps = 0.0;
unsigned int num = 0;
unsigned long int pps = 0;
unsigned short int smurfmode = 0;
unsigned long int bcasts[MAX_LOGABLE];
extern int errno;

int grab_socket(void);
int comp(const void *, const void *);

struct ippkt {
   struct ip ip;
   struct icmp icmp;
} pkt;

int grab_socket(void)
{
   struct protoent *proto;
   int s;

   if (!(proto = getprotobyname("icmp"))) {
      fprintf(stderr, "smurflog: unknown protocol icmp.\n");
      exit(2);
   }

   if ((s = socket(AF_INET, SOCK_RAW, proto->p_proto)) < 0) {
      if ((errno == EPERM) || (errno == EACCES))
         fprintf(stderr, "smurflog: must run as root\n");
      else
         perror("smurflog: socket()");
      exit(2);
   }

   setgid(getgid());
   setuid(getuid());

   return s;
}

int comp(const void *a, const void *b)
{
   return *(int *)a - *(int *)b;
}

int main(void)
{
   int s;
   fd_set fds;
   struct timeval tv = { 0 };
   time_t current = 0, last = 0;
   unsigned char *modip;
   unsigned long int ip;

   s = grab_socket();

   while (1) {
      if (smurfmode) {
         tv.tv_sec = 5;
         FD_ZERO(&fds);
         FD_SET(s, &fds);
         if (!select(s+1,&fds,NULL,NULL,&tv)) {
            smurfmode = 0;
            time(&current);
            printf("%.15s No longer in smurf mode.\n",ctime(&current)+4);
            fflush(stdout);
            num = 0;
         }
      }

      recv(s, (void *)&pkt, sizeof(pkt), 0);

      if (pkt.icmp.icmp_type == ICMP_ECHOREPLY) {
         if (smurfmode) {
            modip = (unsigned char *)&pkt.ip.saddr;
            modip[3] = '\0';
            ip = pkt.ip.saddr;

            if (num > MAX_LOGABLE) continue;

            if (bsearch(&ip, bcasts, num, sizeof(*bcasts), comp) == NULL) {
               printf("#%ld - Probable Smurf attack detected from %s/24 (%d bytes)\n",
			num, inet_ntoa(*((struct in_addr *)&(ip))),
			ntohs(pkt.ip.ip_len));
               fflush(stdout);
               bcasts[num++] = ip;
               qsort(bcasts,num,sizeof(*bcasts),comp);
            }
         } else {
            pps++;
            kbps += ntohs(pkt.ip.ip_len) / 1024.0;
            time(&current);

            if (current - last >= 1 || current < last) {
               pps = 0;
               kbps = 0.0;
            } else if (pps >= THRESHOLD_PPS && kbps >= THRESHOLD_KBPS && !smurfmode) {
               smurfmode = 1;
               printf("%.15s Threshold reached, %ld pkt/s %4.02f kbps, Entering smurf mode.\n",ctime(&current)+4,pps,kbps);
               fflush(stdout);
            }

            last = current;
         }
      }
   }
}

/* Set this to the rate of echo reply packets required to start logging */
/* pps is packets/sec, both pps & kbps must be met to begin logging */
/* kbps is kilobytes/sec not kilobits. If you want kilobits get a Cisco =) */
#define THRESHOLD_PPS	100
#define THRESHOLD_KBPS	50

/* This is the maximium number of broadcasts that will be logged during any
   one attack. A limit is required to prevent potential denial of service
   attacks against the logger. The memory required for the entire list is
   allocated once up front. During a real smurf attack you are never going
   to go over a reasonable number of broadcasts (such as 500). The memory
   required is 4 bytes * MAX_LOGABLE, so if you use the default of 500 the
   memory requirement is 2k. Under the old system memory usage could go as
   high as 4*(256*256*256) bytes or 64MB. */
#define MAX_LOGABLE	500
